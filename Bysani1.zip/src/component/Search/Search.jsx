import React from 'react'
import Header from '../Profile/header'

const Search = () => {
  return (
    <div>
      <Header/>
    </div>
  )
}

export default Search
